import KasBotLanding from "./landing_page_kas_bot_wa_expense_tracker";
export default function App() {
  return <KasBotLanding />;
}
